/* Autenticación con simulación de JWT (localStorage/sessionStorage) y persistencia en JSON Server */
(function () {
  const ADMIN_CODE = "ADMIN123";
  const STAFF_CODE = "MANI123"; // código para crear cuentas de manicurista (CÁMBIALO)
  const JWT_KEY = "maryNailsJWT_v1";
  const LOCK_KEY = "maryNailsLock_v1";
  const MAX_TRIES = 5, LOCK_MS = 60000, ROUNDS = 5000;

  /* ---------- SHA-256 ---------- */
  const P = []; for (let n = 2; P.length < 64; n++) if (P.every(p => n % p)) P.push(n);
  const frac = x => x - Math.floor(x);
  const K = P.map(p => Math.floor(frac(Math.cbrt(p)) * 4294967296) >>> 0);
  const H0 = P.slice(0, 8).map(p => Math.floor(frac(Math.sqrt(p)) * 4294967296) >>> 0);
  function sha256(str) {
    const bytes = new TextEncoder().encode(str), l = bytes.length, total = ((l + 9 + 63) >> 6) << 6;
    const buf = new Uint8Array(total); buf.set(bytes); buf[l] = 0x80;
    const dv = new DataView(buf.buffer); dv.setUint32(total - 4, (l * 8) >>> 0); dv.setUint32(total - 8, Math.floor(l * 8 / 4294967296));
    let h = H0.slice(); const w = new Uint32Array(64);
    for (let o = 0; o < total; o += 64) {
      for (let i = 0; i < 16; i++) w[i] = dv.getUint32(o + i * 4);
      for (let i = 16; i < 64; i++) {
        const a = w[i - 15], b = w[i - 2];
        const s0 = ((a >>> 7) | (a << 25)) ^ ((a >>> 18) | (a << 14)) ^ (a >>> 3);
        const s1 = ((b >>> 17) | (b << 15)) ^ ((b >>> 19) | (b << 13)) ^ (b >>> 10);
        w[i] = (w[i - 16] + s0 + w[i - 7] + s1) >>> 0;
      }
      let [a, b, c, d, e, f, g, hh] = h;
      for (let i = 0; i < 64; i++) {
        const S1 = ((e >>> 6) | (e << 26)) ^ ((e >>> 11) | (e << 21)) ^ ((e >>> 25) | (e << 7));
        const ch = (e & f) ^ (~e & g), t1 = (hh + S1 + ch + K[i] + w[i]) >>> 0;
        const S0 = ((a >>> 2) | (a << 30)) ^ ((a >>> 13) | (a << 19)) ^ ((a >>> 22) | (a << 10));
        const maj = (a & b) ^ (a & c) ^ (b & c), t2 = (S0 + maj) >>> 0;
        hh = g; g = f; f = e; e = (d + t1) >>> 0; d = c; c = b; b = a; a = (t1 + t2) >>> 0;
      }
      h = [h[0] + a, h[1] + b, h[2] + c, h[3] + d, h[4] + e, h[5] + f, h[6] + g, h[7] + hh].map(x => x >>> 0);
    }
    return h.map(x => x.toString(16).padStart(8, "0")).join("");
  }
  function hashPw(pw, salt) { let h = sha256(salt + ":" + pw); for (let i = 0; i < ROUNDS; i++) h = sha256(h + salt); return h; }
  function newSalt() { const a = new Uint8Array(16); crypto.getRandomValues(a); return [...a].map(x => x.toString(16).padStart(2, "0")).join(""); }

  /* ---------- Generación y Decodificación de JWT Simulado ---------- */
  const b64url = obj => btoa(unescape(encodeURIComponent(JSON.stringify(obj)))).replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
  function createJWT(user) {
    const header = b64url({ alg: "HS256", typ: "JWT" });
    const payload = b64url({
      sub: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      iat: Math.floor(Date.now() / 1000),
      exp: Math.floor(Date.now() / 1000) + (60 * 60 * 4) // Expira en 4 horas
    });
    const signature = sha256(`${header}.${payload}.MaryNailsSecretKey2026`).slice(0, 32);
    return `${header}.${payload}.${signature}`;
  }

  function decodeJWT(token) {
    if (!token || token.split(".").length !== 3) return null;
    try {
      const payloadStr = decodeURIComponent(escape(atob(token.split(".")[1].replace(/-/g, "+").replace(/_/g, "/"))));
      const payload = JSON.parse(payloadStr);
      if (payload.exp && payload.exp < Math.floor(Date.now() / 1000)) {
        endSession();
        return null;
      }
      return payload;
    } catch {
      return null;
    }
  }

  /* ---------- Sesión ---------- */
  const normEmail = e => String(e || "").trim().toLowerCase();
  window.currentUser = function () {
    let token = null;
    try { token = sessionStorage.getItem(JWT_KEY) || localStorage.getItem(JWT_KEY); } catch {}
    const payload = decodeJWT(token);
    if (!payload) return null;
    return data.users.find(u => u.id === payload.sub) || { id: payload.sub, name: payload.name, email: payload.email, role: payload.role };
  };
  window.isAdmin = () => { const u = currentUser(); return !!u && u.role === "administrador"; };
  // Personal del salón: administrador o manicurista
  window.isStaff = () => { const u = currentUser(); return !!u && (u.role === "administrador" || u.role === "manicurista"); };
  const ROLE_LABEL = { administrador: "Administrador", manicurista: "Manicurista", cliente: "Cliente" };

  function startSession(user, remember) {
    const jwt = createJWT(user);
    try {
      sessionStorage.removeItem(JWT_KEY);
      localStorage.removeItem(JWT_KEY);
      (remember ? localStorage : sessionStorage).setItem(JWT_KEY, jwt);
    } catch {}
  }
  function endSession() {
    try { sessionStorage.removeItem(JWT_KEY); localStorage.removeItem(JWT_KEY); } catch {}
  }

  /* ---------- Bloqueo por intentos fallidos ---------- */
  function getLocks() { try { return JSON.parse(localStorage.getItem(LOCK_KEY)) || {}; } catch { return {}; } }
  function setLocks(l) { try { localStorage.setItem(LOCK_KEY, JSON.stringify(l)); } catch {} }

  /* ---------- Navegación protegida ---------- */
  const NEED_LOGIN = ["agendar", "miscitas"], NEED_ADMIN = ["clientes"], NEED_STAFF = ["citas"], GUEST_ONLY = ["login", "registro"];
  let pendingView = null;
  const baseGo = window.go;
  window.go = function (view) {
    const u = currentUser();
    if (NEED_ADMIN.includes(view) && !(u && u.role === "administrador")) {
      if (!u) { pendingView = view; toast("Inicia sesión como administrador para entrar."); return baseGo("login"); }
      toast("Esta sección es solo para administradores."); return baseGo("inicio");
    }
    if (NEED_STAFF.includes(view) && !(u && (u.role === "administrador" || u.role === "manicurista"))) {
      if (!u) { pendingView = view; toast("Inicia sesión como administrador o manicurista para entrar."); return baseGo("login"); }
      toast("Esta sección es solo para el personal del salón."); return baseGo("inicio");
    }
    if (NEED_LOGIN.includes(view) && !u) { pendingView = view; toast("Inicia sesión o crea tu cuenta para continuar."); return baseGo("login"); }
    if (GUEST_ONLY.includes(view) && u) return baseGo("inicio");
    baseGo(view);
    if (view === "agendar") prefillBooking();
  };
  window.prefillBooking = function () {
    const u = currentUser(), f = document.getElementById("bookingForm"); if (!u || !f) return;
    if (!f.elements.name.value) f.elements.name.value = u.name;
    if (!f.phone.value) f.phone.value = u.phone || "";
    if (!f.email.value) f.email.value = u.email;
  };

  /* ---------- Interfaz según el rol ---------- */
  window.refreshAuthUI = function () {
    const u = currentUser(), role = u ? u.role : null;
    document.querySelectorAll("[data-show]").forEach(el => {
      const w = el.dataset.show;
      el.hidden = !((w === "guest" && !u) || (w === "user" && u) || (w === "cliente" && role === "cliente") || (w === "admin" && role === "administrador") || (w === "staff" && (role === "administrador" || role === "manicurista")));
    });
    if (u) {
      document.getElementById("userAvatar").textContent = u.name.trim().charAt(0).toUpperCase();
      document.getElementById("userName").textContent = u.name.split(" ")[0];
      document.getElementById("userRole").textContent = ROLE_LABEL[role] || "Cliente";
    }
  };
  function afterLogin(u) {
    refreshAuthUI();
    const isAdm = u.role === "administrador", isStf = isAdm || u.role === "manicurista";
    const target = pendingView && ((NEED_ADMIN.includes(pendingView) && !isAdm) || (NEED_STAFF.includes(pendingView) && !isStf) ? null : pendingView);
    pendingView = null;
    toast(`¡Hola, ${u.name.split(" ")[0]}! Token JWT generado.`);
    go(target || (isStf ? "citas" : "inicio"));
  }

  /* ---------- Registro ---------- */
  const $ = s => document.querySelector(s);
  const regForm = $("#registerForm"), loginForm = $("#loginForm");
  function setErr(id, msg) { const el = $(id); el.textContent = msg || ""; }
  function syncRole() {
    const r = regForm.elements.role.value, needCode = r !== "cliente";
    $("#adminCodeWrap").hidden = !needCode; regForm.adminCode.required = needCode;
    $("#adminCodeLabel").textContent = r === "manicurista" ? "Código de manicurista" : "Código de administrador";
    regForm.adminCode.placeholder = r === "manicurista" ? "Escribe el código de manicurista" : "Escribe el código de administrador";
    $("#registerTitle").textContent = r === "administrador" ? "Registro de administrador" : r === "manicurista" ? "Registro de manicurista" : "Crear cuenta de cliente";
  }
  regForm.querySelectorAll('[name="role"]').forEach(r => r.addEventListener("change", syncRole));

  regForm.addEventListener("submit", async e => {
    e.preventDefault(); setErr("#registerError", "");
    const f = regForm, name = f.elements.name.value.trim().replace(/\s+/g, " "), email = normEmail(f.email.value), phone = f.phone.value.trim();
    const pw = f.password.value, pw2 = f.password2.value, role = f.elements.role.value;
    if (name.length < 3) return setErr("#registerError", "Escribe tu nombre completo.");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) return setErr("#registerError", "Escribe un correo válido.");
    if (!/^[0-9+ ()-]{7,}$/.test(phone)) return setErr("#registerError", "Escribe un teléfono válido (mínimo 7 dígitos).");
    if (pw.length < 8 || !/[A-Za-z]/.test(pw) || !/[0-9]/.test(pw)) return setErr("#registerError", "La contraseña debe tener mínimo 8 caracteres, con letras y números.");
    if (pw !== pw2) return setErr("#registerError", "Las contraseñas no coinciden.");
    if (role === "administrador" && f.adminCode.value.trim() !== ADMIN_CODE) return setErr("#registerError", "El código de administrador no es correcto.");
    if (role === "manicurista" && f.adminCode.value.trim() !== STAFF_CODE) return setErr("#registerError", "El código de manicurista no es correcto.");
    if (data.users.some(u => normEmail(u.email) === email)) return setErr("#registerError", "Ya existe una cuenta con ese correo. Inicia sesión.");
    
    const salt = newSalt();
    const user = { id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()), name, email, phone, role, salt, hash: hashPw(pw, salt), createdAt: new Date().toISOString() };
    
    await fetch("http://localhost:3000/users", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(user)
    }).catch(() => {});

    data.users.push(user); save();
    f.reset(); syncRole();
    startSession(user, true);
    toast(role === "administrador" ? "Cuenta de administrador creada." : role === "manicurista" ? "Cuenta de manicurista creada." : "¡Cuenta creada! Ya puedes agendar tu cita.");
    afterLogin(user);
  });

  /* ---------- Inicio de sesión ---------- */
  loginForm.addEventListener("submit", e => {
    e.preventDefault(); setErr("#loginError", "");
    const email = normEmail(loginForm.email.value), pw = loginForm.password.value;
    if (!email || !pw) return setErr("#loginError", "Ingresa tu correo y tu contraseña.");
    const locks = getLocks(), lk = locks[email];
    if (lk && lk.until > Date.now()) return setErr("#loginError", `Demasiados intentos. Intenta de nuevo en ${Math.ceil((lk.until - Date.now()) / 1000)} s.`);
    const user = data.users.find(u => normEmail(u.email) === email);
    if (!user || hashPw(pw, user.salt) !== user.hash) {
      const n = ((lk && lk.n) || 0) + 1;
      locks[email] = { n: n >= MAX_TRIES ? 0 : n, until: n >= MAX_TRIES ? Date.now() + LOCK_MS : 0 };
      setLocks(locks);
      return setErr("#loginError", n >= MAX_TRIES ? "Demasiados intentos fallidos. Espera 1 minuto." : "Correo o contraseña incorrectos.");
    }
    delete locks[email]; setLocks(locks);
    startSession(user, loginForm.remember.checked);
    loginForm.reset(); loginForm.remember.checked = true;
    afterLogin(user);
  });

  /* ---------- Salir y mostrar/ocultar contraseña ---------- */
  $("#logoutBtn").addEventListener("click", () => {
    endSession(); pendingView = null; refreshAuthUI();
    toast("Sesión cerrada."); go("inicio");
  });
  document.addEventListener("click", e => {
    const t = e.target.closest("[data-toggle-pw]"); if (!t) return;
    const inp = t.parentElement.querySelector("input"); const show = inp.type === "password";
    inp.type = show ? "text" : "password"; t.textContent = show ? "Ocultar" : "Mostrar";
  });

  refreshAuthUI();
  syncRole();
})();