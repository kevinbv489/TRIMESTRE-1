const API_URL = "http://localhost:3000";
const STORAGE_KEY = "maryNailsData_v1";

const defaultServices = [
  { id: "s1", name: "Manicure tradicional", description: "Limpieza, limado, cuidado de cutícula y esmaltado clásico.", price: 25000, duration: 45, icon: "✿" },
  { id: "s2", name: "Semipermanente", description: "Esmaltado de larga duración con acabado brillante.", price: 45000, duration: 60, icon: "♡" },
  { id: "s3", name: "Uñas acrílicas", description: "Extensión y construcción de uñas con acabado personalizado.", price: 85000, duration: 120, icon: "✧" },
  { id: "s4", name: "Pedicure", description: "Cuidado de pies, uñas y esmaltado tradicional.", price: 35000, duration: 60, icon: "❀" },
  { id: "s5", name: "Diseño de uñas", description: "Decoración personalizada para darle un toque único a tus uñas.", price: 15000, duration: 30, icon: "✦" },
  { id: "s6", name: "Retiro de producto", description: "Retiro cuidadoso del producto aplicado anteriormente.", price: 18000, duration: 30, icon: "❋" },
  { id: "s7", name: "Keratinas", description: "Tratamiento de alisado y nutrición para un cabello suave, liso y brillante.", price: 120000, duration: 150, icon: "✺" },
  { id: "s8", name: "Peinados", description: "Peinados para toda ocasión: recogidos, ondas, planchado y más.", price: 60000, duration: 60, icon: "❃" }
];

let data = { services: defaultServices, appointments: [], users: [] };

async function initBackend() {
  try {
    const [resS, resA, resU] = await Promise.all([
      fetch(`${API_URL}/services`),
      fetch(`${API_URL}/appointments`),
      fetch(`${API_URL}/users`)
    ]);
    data.services = await resS.json();
    data.appointments = await resA.json();
    data.users = await resU.json();
  } catch (err) {
    console.warn("Usando respaldo local:", err);
    try {
      const d = JSON.parse(localStorage.getItem(STORAGE_KEY)) || {};
      data = { services: d.services || defaultServices, appointments: d.appointments || [], users: d.users || [] };
    } catch {}
  }
  renderServices();
  if (typeof refreshAuthUI === "function") refreshAuthUI();
}

function save() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}

const money = n => new Intl.NumberFormat("es-CO", { style: "currency", currency: "COP", maximumFractionDigits: 0 }).format(n);
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
function escapeHTML(s = "") {
  const d = document.createElement("div");
  d.textContent = String(s);
  return d.innerHTML;
}

function go(view) {
  $$(".view").forEach(v => v.classList.toggle("active", v.id === `view-${view}`));
  $$(".nav-link").forEach(b => b.classList.toggle("active", b.dataset.view === view));
  $("#mainNav").classList.remove("open");
  if (view === "clientes") renderClients();
  if (view === "citas") renderAppointments();
  if (view === "miscitas") renderMine();
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function toast(msg) {
  const el = $("#toast");
  if (!el) return;
  el.textContent = msg;
  el.classList.add("show");
  setTimeout(() => el.classList.remove("show"), 2600);
}

// Imagen de cada servicio (por id). Si un servicio no está aquí, se muestra el emoji de respaldo.
const serviceImages = {
  s1: { src: "img/unas-clasicas.jpg", w: 547, h: 365, alt: "Manicure tradicional: uñas clásicas con esmaltado" },
  s2: { src: "img/semipermanente.jpg", w: 554, h: 554, alt: "Uñas con esmaltado semipermanente brillante" },
  s3: { src: "img/acrilicas.jpg", w: 452, h: 678, alt: "Uñas acrílicas con acabado personalizado" },
  s4: { src: "img/pedicure.jpg", w: 713, h: 429, alt: "Pedicure: cuidado de pies y uñas" },
  s5: { src: "img/disenos.jpg", w: 509, h: 602, alt: "Diseños de uñas decoradas" },
  s6: { src: "img/retiro.jpg", w: 678, h: 452, alt: "Retiro de producto de uñas" },
  s7: { src: "img/keratinas.jpg", w: 463, h: 662, alt: "Tratamiento de keratina para el cabello" },
  s8: { src: "img/peinados.jpg", w: 447, h: 447, alt: "Peinado para toda ocasión" }
};

function serviceCard(s) {
  const img = serviceImages[s.id];
  const media = img
    ? `<img class="service-photo" src="${img.src}" width="${img.w}" height="${img.h}" alt="${escapeHTML(img.alt)}" loading="lazy" data-icon="${escapeHTML(s.icon || "")}">`
    : `<div class="service-icon">${s.icon}</div>`;
  return `<article class="service-card">${media}<h3>${escapeHTML(s.name)}</h3><p>${escapeHTML(s.description)}</p><div class="service-meta"><strong>${money(s.price)}</strong><span>${s.duration} min</span></div><button class="text-button" data-book="${s.id}">Reservar este servicio →</button></article>`;
}

// Respaldo: si una foto de servicio no carga, vuelve a mostrarse el emoji (sin onerror en línea por la CSP)
document.addEventListener("error", e => {
  const im = e.target;
  if (!(im instanceof HTMLImageElement) || !im.classList.contains("service-photo")) return;
  const d = document.createElement("div");
  d.className = "service-icon";
  d.textContent = im.dataset.icon || "✦";
  im.replaceWith(d);
}, true);

function renderServices() {
  $("#featuredServices").innerHTML = data.services.slice(0, 3).map(serviceCard).join("");
  $("#allServices").innerHTML = data.services.map(serviceCard).join("");
  $("#serviceSelect").innerHTML = '<option value="">Selecciona un servicio</option>' + data.services.map(s => `<option value="${s.id}">${escapeHTML(s.name)} — ${money(s.price)}</option>`).join("");
}

function getClients() {
  const rows = data.users.filter(u => u.role === "cliente").map(u => {
    const mine = data.appointments.filter(a => a.userId === u.id);
    return { name: u.name, phone: u.phone, email: u.email, date: mine.map(a => a.date).sort().pop() || "", count: mine.length, since: u.createdAt, account: true };
  });
  const guests = new Map();
  data.appointments.filter(a => !a.userId).forEach(a => {
    const k = a.phone.replace(/\D/g, "");
    const g = guests.get(k);
    if (!g) guests.set(k, { name: a.name, phone: a.phone, email: a.email, date: a.date, count: 1, account: false });
    else { g.count++; if (g.date < a.date) Object.assign(g, { name: a.name, email: a.email, date: a.date }); }
  });
  return [...rows, ...guests.values()].sort((a, b) => a.name.localeCompare(b.name));
}

function renderClients() {
  const q = $("#clientSearch").value.toLowerCase();
  const clients = getClients().filter(c => (c.name + " " + c.phone + " " + c.email).toLowerCase().includes(q));
  $("#clientCount").textContent = `${clients.length} cliente(s)`;
  $("#clientsBody").innerHTML = clients.length ? clients.map(c => `<tr><td><strong>${escapeHTML(c.name)}</strong></td><td>${escapeHTML(c.phone)}</td><td>${escapeHTML(c.email || "—")}</td><td>${c.count}</td><td>${formatDate(c.date)}</td><td>${c.account ? `Cuenta · ${formatDate((c.since || "").slice(0, 10))}` : '<span class="muted">Sin cuenta</span>'}</td></tr>`).join("") : '<tr><td colspan="6" class="empty">Aún no hay clientes registrados.</td></tr>';
}

function formatDate(d) {
  if (!d) return "—";
  return new Date(d + "T12:00:00").toLocaleDateString("es-CO", { day: "2-digit", month: "short", year: "numeric" });
}

function renderAppointments() {
  const q = $("#appointmentSearch").value.toLowerCase(), filter = $("#statusFilter").value;
  const list = data.appointments.filter(a => (filter === "Todas" || a.status === filter) && (a.name + " " + a.service).toLowerCase().includes(q)).sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time));
  $("#appointmentStats").innerHTML = [["Total", data.appointments.length], ["Pendientes", data.appointments.filter(a => a.status === "Pendiente").length], ["Confirmadas", data.appointments.filter(a => a.status === "Confirmada").length]].map(([l, n]) => `<div class="stat"><span>${l}</span><strong>${n}</strong></div>`).join("");
  $("#appointmentsBody").innerHTML = list.length ? list.map(a => `<tr><td><strong>${escapeHTML(a.name)}</strong><br><span class="muted">${escapeHTML(a.phone)}</span></td><td>${escapeHTML(a.service)}</td><td>${formatDate(a.date)} · ${escapeHTML(a.time)}</td><td><span class="status ${a.status}">${a.status}</span></td><td>${a.status !== "Cancelada" ? `<button class="action-btn" data-confirm="${a.id}">Confirmar</button><button class="action-btn danger" data-cancel="${a.id}">Cancelar</button>` : "—"} ${isAdmin() ? `<button class="action-btn danger" data-delete="${a.id}">Eliminar</button>` : ""}</td></tr>`).join("") : '<tr><td colspan="5" class="empty">No hay citas que coincidan con la búsqueda.</td></tr>';
}

function renderMine() {
  const u = currentUser(); if (!u) return;
  const list = data.appointments.filter(a => a.userId === u.id).sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time));
  $("#myStats").innerHTML = [["Total", list.length], ["Pendientes", list.filter(a => a.status === "Pendiente").length], ["Confirmadas", list.filter(a => a.status === "Confirmada").length]].map(([l, n]) => `<div class="stat"><span>${l}</span><strong>${n}</strong></div>`).join("");
  $("#myBody").innerHTML = list.length ? list.map(a => `<tr><td><strong>${escapeHTML(a.service)}</strong></td><td>${formatDate(a.date)} · ${escapeHTML(a.time)}</td><td><span class="status ${a.status}">${a.status}</span></td><td>${a.status !== "Cancelada" ? `<button class="action-btn danger" data-mycancel="${a.id}">Cancelar</button>` : "—"}</td></tr>`).join("") : '<tr><td colspan="4" class="empty">Aún no tienes citas. <button class="text-button" data-go="agendar">Agenda la primera →</button></td></tr>';
}

function downloadCSV(filename, rows) {
  const csv = rows.map(row => row.map(v => '"' + String(v ?? "").replace(/"/g, '""') + '"').join(";")).join("\n");
  const blob = new Blob(["\ufeff" + csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a"); a.href = url; a.download = filename; a.click(); URL.revokeObjectURL(url);
}

function setMinDate() {
  const d = new Date(); d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
  $("#dateInput").min = d.toISOString().slice(0, 10);
}

function initTimes() {
  $("#timeSelect").innerHTML = '<option value="">Selecciona una hora</option>' + Array.from({ length: 18 }, (_, i) => { const h = 9 + Math.floor(i / 2), m = i % 2 ? "30" : "00"; return `<option>${String(h).padStart(2, "0")}:${m}</option>`; }).join("");
}

async function updateAppointmentStatus(id, status) {
  await fetch(`${API_URL}/appointments/${id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json", "Authorization": `Bearer ${localStorage.getItem("maryNailsJWT_v1") || ""}` },
    body: JSON.stringify({ status })
  }).catch(() => {});
}

document.addEventListener("click", async e => {
  const nav = e.target.closest("[data-view]"); if (nav) { e.preventDefault(); go(nav.dataset.view); return; }
  const goBtn = e.target.closest("[data-go]"); if (goBtn) { go(goBtn.dataset.go); return; }
  const book = e.target.closest("[data-book]"); if (book) { $("#serviceSelect").value = book.dataset.book; go("agendar"); return; }
  const ok = e.target.closest("[data-confirm]");
  if (ok) {
    if (!isStaff()) return;
    const a = data.appointments.find(x => x.id === ok.dataset.confirm);
    if (a) { a.status = "Confirmada"; await updateAppointmentStatus(a.id, "Confirmada"); save(); renderAppointments(); toast("Cita confirmada."); }
    return;
  }
  const cn = e.target.closest("[data-cancel]");
  if (cn) {
    if (!isStaff()) return;
    const a = data.appointments.find(x => x.id === cn.dataset.cancel);
    if (a && window.confirm("¿Deseas cancelar esta cita?")) { a.status = "Cancelada"; await updateAppointmentStatus(a.id, "Cancelada"); save(); renderAppointments(); toast("Cita cancelada."); }
    return;
  }
  const my = e.target.closest("[data-mycancel]");
  if (my) {
    const u = currentUser();
    const a = u && data.appointments.find(x => x.id === my.dataset.mycancel && x.userId === u.id);
    if (a && window.confirm("¿Deseas cancelar tu cita?")) { a.status = "Cancelada"; await updateAppointmentStatus(a.id, "Cancelada"); save(); renderMine(); toast("Tu cita fue cancelada."); }
    return;
  }
  const del = e.target.closest("[data-delete]");
  if (del) {
    if (!isAdmin()) return;
    if (window.confirm("¿Eliminar definitivamente esta cita?")) {
      const id = del.dataset.delete;
      await fetch(`${API_URL}/appointments/${id}`, { method: "DELETE" }).catch(() => {});
      data.appointments = data.appointments.filter(a => a.id !== id);
      save(); renderAppointments(); renderClients(); toast("Cita eliminada.");
    }
  }
});

$("#bookingForm").addEventListener("submit", async e => {
  e.preventDefault();
  const u = currentUser(); if (!u) { go("login"); return; }
  const form = e.currentTarget, f = new FormData(form), s = data.services.find(x => x.id === f.get("service"));
  if (!s) return;
  const appointment = {
    id: String(Date.now()),
    userId: u.id,
    name: f.get("name").trim(),
    phone: f.get("phone").trim(),
    email: f.get("email").trim(),
    service: s.name,
    serviceId: s.id,
    date: f.get("date"),
    time: f.get("time"),
    notes: f.get("notes").trim(),
    status: "Pendiente",
    createdAt: new Date().toISOString()
  };
  if (data.appointments.some(a => a.date === appointment.date && a.time === appointment.time && a.status !== "Cancelada")) {
    toast("Ese horario ya tiene una solicitud. Elige otra hora.");
    return;
  }
  await fetch(`${API_URL}/appointments`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "Authorization": `Bearer ${localStorage.getItem("maryNailsJWT_v1") || ""}` },
    body: JSON.stringify(appointment)
  }).catch(() => {});
  data.appointments.push(appointment);
  save(); form.reset(); prefillBooking();
  $("#bookingMessage").textContent = "¡Tu cita en Mary Nails quedó registrada! Está en estado Pendiente hasta que la confirmemos. Puedes verla en «Mis citas».";
  toast("Tu cita en Mary Nails quedó registrada.");
});

$("#clientSearch").addEventListener("input", renderClients);
$("#appointmentSearch").addEventListener("input", renderAppointments);
$("#statusFilter").addEventListener("change", renderAppointments);
$("#exportClients").addEventListener("click", () => isAdmin() && downloadCSV("clientes_mary_nails.csv", [["Nombre", "Teléfono", "Correo", "Citas", "Última reserva", "Cuenta"], ...getClients().map(c => [c.name, c.phone, c.email, c.count, formatDate(c.date), c.account ? "Registrada" : "Sin cuenta"])]));
$("#exportAppointments").addEventListener("click", () => isAdmin() && downloadCSV("citas_mary_nails.csv", [["Cliente", "Teléfono", "Correo", "Servicio", "Fecha", "Hora", "Estado", "Notas"], ...data.appointments.map(a => [a.name, a.phone, a.email, a.service, a.date, a.time, a.status, a.notes])]));
$("#menuToggle").addEventListener("click", () => $("#mainNav").classList.toggle("open"));
$("#year").textContent = new Date().getFullYear();

renderServices();
initTimes();
setMinDate();
initBackend();